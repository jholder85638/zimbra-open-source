char   *var_lmtp_destination_concurrency_limit;
char   *var_relay_destination_concurrency_limit;
char   *var_smtp_destination_concurrency_limit;
char   *var_virtual_destination_concurrency_limit;
char   *var_lmtp_destination_recipient_limit;
char   *var_smtp_destination_recipient_limit;
char   *var_relay_destination_recipient_limit;
char   *var_virtual_destination_recipient_limit;
