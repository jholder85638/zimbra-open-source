char   *var_config_dir;
