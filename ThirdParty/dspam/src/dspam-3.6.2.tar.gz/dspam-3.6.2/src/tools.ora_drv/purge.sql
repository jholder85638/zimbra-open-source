REM $Id: purge.sql,v 1.1 2004/10/24 20:51:55 jonz Exp $

delete from dspam_token_data 
  where (innocent_hits*2) + spam_hits < 5
  and SYSDATE-last_hit > 30
/

delete from dspam_token_data
  where (innocent_hits = 1 or spam_hits = 1)
  and (innocent_hits = 0 or spam_hits = 0)
  and SYSDATE-last_hit > 15
/

delete from dspam_token_data
  where SYSDATE-last_hit > 90
/

delete from dspam_signature_data
  where SYSDATE-created_on > 14
/
