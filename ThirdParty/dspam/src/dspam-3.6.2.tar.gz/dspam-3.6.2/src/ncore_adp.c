/*

Placeholder for NodalCore(r) C-Series(tm) Hardware Accelerator Adapter

This adapter is only available when licensed.

*/
